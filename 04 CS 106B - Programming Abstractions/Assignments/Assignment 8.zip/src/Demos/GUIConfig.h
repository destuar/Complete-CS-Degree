RUN_TESTS_MENU_OPTION()

MENU_OPTION("Compress a File", makeCompressGUI)
MENU_OPTION("Decompress a File", makeDecompressGUI)

WINDOW_TITLE("Huffman Coding")
