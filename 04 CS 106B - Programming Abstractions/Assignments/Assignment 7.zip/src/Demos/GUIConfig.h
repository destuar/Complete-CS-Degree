RUN_TESTS_MENU_OPTION()

WINDOW_TITLE("The Adventures of Links")
