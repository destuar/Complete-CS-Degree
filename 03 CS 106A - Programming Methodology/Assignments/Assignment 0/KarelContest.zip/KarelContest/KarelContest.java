/*
 * File: KarelContest.java
 * -----------------------
 * This file is the starter file for your Karel Contest entry.
 * Feel free to change the name of this file (and the corresponding
 * class name) to something more descriptive.
 */

import stanford.karel.*;

public class KarelContest extends SuperKarel {

	// You fill in this part

}
