#ifndef RobinHoodTests_Included
#define RobinHoodTests_Included

#include "GUI/TestDriver.h"

/* This logic is necessary to get the testing harness to properly pick up all the tests
 * from your file.
 */
#ifdef GROUP
#undef GROUP
#endif

#define GROUP {2, "Robin Hood Hashing"}

#endif
