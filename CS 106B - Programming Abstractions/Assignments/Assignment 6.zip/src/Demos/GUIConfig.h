RUN_TESTS_MENU_OPTION()

MENU_OPTION("Interactive Linear Probing", makeLinearProbingGUI)
MENU_OPTION("Interactive Robin Hood", makeRobinHoodGUI)

MENU_OPTION("Performance Analysis", makePerformanceGUI)

WINDOW_TITLE("The Great Stanford Hash-Off")
