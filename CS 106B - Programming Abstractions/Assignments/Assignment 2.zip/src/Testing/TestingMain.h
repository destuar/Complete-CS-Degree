#ifndef TestingMain_Included
#define TestingMain_Included

/* Runs all of the testing code. */
void testingMain();

#endif
