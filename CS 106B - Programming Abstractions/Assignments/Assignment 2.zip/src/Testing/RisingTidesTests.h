#ifndef RisingTidesTests_Included
#define RisingTidesTests_Included

#include "Testing/TestDriver.h"

/* This logic is necessary to get the testing harness to properly pick up all the tests
 * from your file.
 */
#ifdef GROUP
#undef GROUP
#endif

#define GROUP {1, "Rising Tides"}

#endif
