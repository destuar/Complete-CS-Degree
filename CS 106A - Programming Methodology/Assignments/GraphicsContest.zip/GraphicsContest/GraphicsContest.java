/*
 * File: GraphicsContest.java
 * --------------------------
 * This file is the starter file for your Karel Contest entry.
 * It is always a good idea to change the name of this file
 * (and the corresponding class name) to something more
 * descriptive.
 */

import acm.program.*;

public class GraphicsContest extends GraphicsProgram {

	public void run() {
		/* You fill this in */
	}

}
