/*
 * File: Adventure.java
 * Names: <fill in>
 * Section leader who is grading the assignment: <fill in>
 * -------------------------------------------------------
 * This is the starter file for the Adventure Contest.  Your
 * code should automatically select the name of the adventure
 * that you are submitting for the contest.  You should also
 * replace this comment with one that describes the special
 * features of your game.
 */

import acm.io.*;
import acm.program.*;
import acm.util.*;
import java.io.*;
import java.util.*;

/**
 * This class is the main program class for the Adventure game.
 * In the final version, <code>Adventure</code> should extend
 * <code>ConsoleProgram</code> directly.
 */

public class Adventure extends AdventureMagicSuperclass {

/**
 * Runs the Adventure program.
 */
	public void run() {
		super.run();  // Replace with your code
	}

// Add your own private methods and instance variables here

}
