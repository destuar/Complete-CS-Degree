/*
 * File: Rainbow.java
 * ------------------
 * This program is a stub for the Rainbow problem, which displays
 * a rainbow by adding consecutively smaller circles to the canvas.
 */

import acm.program.*;

public class Rainbow extends GraphicsProgram {

	public void run() {
		// You fill this in
	}

}
