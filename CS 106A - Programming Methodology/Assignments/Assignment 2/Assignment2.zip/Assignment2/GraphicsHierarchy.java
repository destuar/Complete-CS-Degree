/*
 * File: GraphicsHierarchy.java
 * ----------------------------
 * This program is a stub for the GraphicsHierarchy problem, which
 * draws a partial diagram of the acm.graphics hierarchy.
 */

import acm.program.*;

public class GraphicsHierarchy extends GraphicsProgram {
	
	public void run() {
		// You fill this in
	}

}
