/*
 * File: Pyramid.java
 * ------------------
 * This program is a stub for the Pyramid problem, which draws
 * a brick pyramid.
 */

import acm.program.*;

public class Pyramid extends GraphicsProgram {

	public void run() {
		// You fill this in
	}

}
