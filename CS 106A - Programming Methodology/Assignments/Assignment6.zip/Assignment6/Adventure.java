/*
 * File: Adventure.java
 * Names: <fill in>
 * Section leader who is grading the assignment: <fill in>
 * -------------------------------------------------------
 * This program plays the Adventure game from Assignment #6.
 */

import acm.io.*;
import acm.program.*;
import acm.util.*;
import java.io.*;
import java.util.*;

/**
 * This class is the main program class for the Adventure game.
 * In the final version, <code>Adventure</code> should extend
 * <code>ConsoleProgram</code> directly.
 */

public class Adventure extends AdventureMagicSuperclass {

/**
 * Runs the Adventure program.
 */
	public void run() {
		super.run();  // Replace with your code
	}

// Add your own private methods and instance variables here

}
